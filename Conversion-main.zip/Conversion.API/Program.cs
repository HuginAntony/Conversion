using System.Text;
using Conversion.API.Middleware;
using Conversion.API.Policies;
using Conversion.Core.Contracts;
using Conversion.Core.Converters;
using Conversion.DataAccess;
using Conversion.DataAccess.Core;
using Conversion.DataAccess.Interfaces;
using Conversion.DataAccess.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// -- Controllers -------------------------------------------------------------
builder.Services.AddControllers();
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<Conversion.API.Middleware.GlobalExceptionHandler>();

// -- OpenAPI ------------------------------------------------------------------
builder.Services.AddOpenApi();

// -- AutoMapper ---------------------------------------------------------------
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

// -- Unit Converters ----------------------------------------------------------
builder.Services.AddScoped<ITemperatureConverter, TemperatureConverter>();
builder.Services.AddScoped<IMassConverter, MassConverter>();
builder.Services.AddScoped<ILengthConverter, LengthConverter>();
builder.Services.AddScoped<ISpeedConverter, SpeedConverter>();
builder.Services.AddScoped<IVolumeConverter, VolumeConverter>();
builder.Services.AddScoped<IAreaConverter, AreaConverter>();
builder.Services.AddScoped<IDataStorageConverter, DataStorageConverter>();

// Register all converters as IUnitConverter for discovery/routing
builder.Services.AddScoped<IUnitConverter, TemperatureConverter>();
builder.Services.AddScoped<IUnitConverter, MassConverter>();
builder.Services.AddScoped<IUnitConverter, LengthConverter>();
builder.Services.AddScoped<IUnitConverter, SpeedConverter>();
builder.Services.AddScoped<IUnitConverter, VolumeConverter>();
builder.Services.AddScoped<IUnitConverter, AreaConverter>();
builder.Services.AddScoped<IUnitConverter, DataStorageConverter>();

// -- Database -----------------------------------------------------------------
builder.Services.AddDbContext<ConversionDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConversionDB")));

// -- Repository / UoW ---------------------------------------------------------
builder.Services.AddScoped<IUnitOfWork<ConversionDbContext>, UnitOfWork<ConversionDbContext>>();
builder.Services.AddScoped(
    typeof(IRepository<ConversionHistory>),
    typeof(EfRepository<ConversionDbContext, ConversionHistory>));

// -- Identity -----------------------------------------------------------------
builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
    .AddEntityFrameworkStores<ConversionDbContext>()
    .AddDefaultTokenProviders();

// -- Authentication � JWT Bearer -----------------------------------------------
var jwtSection = builder.Configuration.GetSection("Jwt");
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme    = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme             = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = true;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer           = true,
        ValidateAudience         = true,
        ValidateLifetime         = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer              = jwtSection["Issuer"],
        ValidAudience            = jwtSection["Audience"],
        IssuerSigningKey         = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(jwtSection["SecretKey"]!)),
        ClockSkew = TimeSpan.Zero,
    };
});

// -- Authorization Policies ----------------------------------------------------
builder.Services.AddAuthorization(config =>
{
    config.AddPolicy(UserRoles.Admin, Policy.AdminPolicy());
    config.AddPolicy(UserRoles.User, Policy.UserPolicy());
});

// -- Health Checks -------------------------------------------------------------
builder.Services.AddHealthChecks();

// -- CORS ----------------------------------------------------------------------
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins(builder.Configuration["AllowedOrigin"] ?? "http://localhost:4200")
              .AllowAnyMethod()
              .AllowAnyHeader());
});

// -----------------------------------------------------------------------------
var app = builder.Build();
// -----------------------------------------------------------------------------

app.UseExceptionHandler();
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseHttpsRedirection();
app.UseCors();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();

// Needed for WebApplicationFactory in integration tests
public partial class Program { }
