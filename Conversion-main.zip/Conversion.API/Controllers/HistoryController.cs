using AutoMapper;
using Conversion.Core.ApiModels;
using Conversion.DataAccess;
using Conversion.DataAccess.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Conversion.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public sealed class HistoryController(
    IRepository<ConversionHistory> repository,
    IUnitOfWork<ConversionDbContext> unitOfWork,
    IMapper mapper) : ControllerBase
{
    [HttpGet("{userId}")]
    [ProducesResponseType(typeof(IEnumerable<HistoryResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<HistoryResponse>>> GetHistoryByUser(
        string userId, CancellationToken cancellationToken)
    {
        var history = await repository
            .LazyGet(h => h.UserId == userId)
            .Include(h => h.User)
            .ToListAsync(cancellationToken);

        return Ok(mapper.Map<List<HistoryResponse>>(history));
    }

    [HttpPost]
    [ProducesResponseType(typeof(HistoryResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<HistoryResponse>> SaveHistory(
        [FromBody] HistoryRequest request, CancellationToken cancellationToken)
    {
        var entity = mapper.Map<ConversionHistory>(request);
        entity.CreatedAt = DateTimeOffset.UtcNow;

        repository.Insert(entity);
        await unitOfWork.CommitAsync(cancellationToken);

        return CreatedAtAction(nameof(GetHistoryByUser), new { userId = entity.UserId }, mapper.Map<HistoryResponse>(entity));
    }
}
