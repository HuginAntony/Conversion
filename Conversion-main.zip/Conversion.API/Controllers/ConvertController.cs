using Conversion.Core.ApiModels;
using Conversion.Core.Contracts;
using Conversion.Core.Models;
using Microsoft.AspNetCore.Mvc;

namespace Conversion.API.Controllers;

/// <summary>
/// Unified converter endpoint. Resolves the correct converter by <paramref name="category"/> at runtime.
/// This self-routing design allows new categories to be added without modifying this controller.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public sealed class ConvertController(IEnumerable<IUnitConverter> converters) : ControllerBase
{
    /// <summary>
    /// Returns all supported categories and their unit lists.
    /// </summary>
    [HttpGet("categories")]
    [ProducesResponseType(typeof(IEnumerable<object>), StatusCodes.Status200OK)]
    public ActionResult<IEnumerable<object>> GetCategories()
    {
        var result = converters.Select(c => new
        {
            c.Category,
            c.SupportedUnits,
        });
        return Ok(result);
    }

    /// <summary>
    /// Returns all supported units for the given category.
    /// </summary>
    [HttpGet("{category}/units")]
    [ProducesResponseType(typeof(IEnumerable<string>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public ActionResult<IEnumerable<string>> GetUnits(string category)
    {
        var converter = FindConverter(category);
        if (converter is null)
            return NotFound(new { Message = $"Category '{category}' not found." });

        return Ok(converter.SupportedUnits);
    }

    /// <summary>
    /// Convert a value between two units within the given category.
    /// </summary>
    [HttpPost("{category}")]
    [ProducesResponseType(typeof(ConversionResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ConversionResult>> Convert(
        string category,
        [FromBody] ConversionRequest request,
        CancellationToken cancellationToken)
    {
        var converter = FindConverter(category);
        if (converter is null)
            return NotFound(new { Message = $"Category '{category}' not found." });

        var result = await converter.ConvertAsync(request.Value, request.FromUnit, request.ToUnit, cancellationToken);
        return Ok(result);
    }

    private IUnitConverter? FindConverter(string category)
        => converters.FirstOrDefault(c =>
            string.Equals(c.Category, category, StringComparison.OrdinalIgnoreCase));
}
