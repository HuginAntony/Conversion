using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Conversion.API.Policies;
using Conversion.Core.ApiModels;
using Conversion.DataAccess.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace Conversion.API.Controllers;

[ApiController]
[Route("[controller]")]
[Produces("application/json")]
public sealed class AuthController(
    UserManager<ApplicationUser> userManager,
    RoleManager<IdentityRole> roleManager,
    IConfiguration configuration) : ControllerBase
{
    [HttpPost("login")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        var user = await userManager.FindByNameAsync(request.Username);
        if (user is null || !await userManager.CheckPasswordAsync(user, request.Password))
            return BadRequest(new { Message = "Invalid username or password." });

        var token = await GenerateJwtTokenAsync(user);
        return Ok(new { token });
    }

    [HttpPost("register")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request, CancellationToken cancellationToken)
    {
        if (await userManager.FindByNameAsync(request.Username) is not null)
            return Conflict(new ErrorResponse("User already exists."));

        var user = new ApplicationUser
        {
            Email         = request.Email,
            SecurityStamp = Guid.NewGuid().ToString(),
            UserName      = request.Username,
            EmailConfirmed = true,
        };

        var result = await userManager.CreateAsync(user, request.Password);
        if (!result.Succeeded)
            return BadRequest(new ErrorResponse(string.Join(", ", result.Errors.Select(e => e.Description))));

        await EnsureRoleAndAssignAsync(user, UserRoles.User);
        return Ok();
    }

    [HttpPost("register-admin")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> RegisterAdmin([FromBody] RegisterRequest request, CancellationToken cancellationToken)
    {
        if (await userManager.FindByNameAsync(request.Username) is not null)
            return Conflict(new ErrorResponse("User already exists."));

        var user = new ApplicationUser
        {
            Email         = request.Email,
            SecurityStamp = Guid.NewGuid().ToString(),
            UserName      = request.Username,
            EmailConfirmed = true,
        };

        var result = await userManager.CreateAsync(user, request.Password);
        if (!result.Succeeded)
            return BadRequest(new ErrorResponse(string.Join(", ", result.Errors.Select(e => e.Description))));

        await EnsureRoleAndAssignAsync(user, UserRoles.Admin);
        return Ok();
    }

    // -- Private Helpers ------------------------------------------------------

    private async Task EnsureRoleAndAssignAsync(ApplicationUser user, string role)
    {
        if (!await roleManager.RoleExistsAsync(role))
            await roleManager.CreateAsync(new IdentityRole(role));
        await userManager.AddToRoleAsync(user, role);
    }

    private async Task<string> GenerateJwtTokenAsync(ApplicationUser user)
    {
        var userRoles = await userManager.GetRolesAsync(user);

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Email,  user.Email ?? string.Empty),
            new(JwtRegisteredClaimNames.NameId, user.UserName ?? string.Empty),
            new(JwtRegisteredClaimNames.Sid,    user.Id),
            new(JwtRegisteredClaimNames.Jti,    Guid.NewGuid().ToString()),
        };

        claims.AddRange(userRoles.Select(r => new Claim(ClaimTypes.Role, r)));

        var signingKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(configuration["Jwt:SecretKey"]!));

        var descriptor = new SecurityTokenDescriptor
        {
            Issuer             = configuration["Jwt:Issuer"],
            Audience           = configuration["Jwt:Audience"],
            Expires            = DateTime.UtcNow.AddHours(3),
            Subject            = new ClaimsIdentity(claims),
            SigningCredentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256),
        };

        var handler = new JwtSecurityTokenHandler();
        return handler.WriteToken(handler.CreateToken(descriptor));
    }
}
