using Conversion.DataAccess;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Conversion.API.Tests;

/// <summary>
/// Integration test factory. Uses an in-memory database instead of SQL Server.
/// </summary>
public sealed class TestFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Test");

        builder.ConfigureServices(services =>
        {
            // Remove real SQL Server registration
            var descriptor = services.SingleOrDefault(
                d => d.ServiceType == typeof(DbContextOptions<ConversionDbContext>));
            if (descriptor is not null)
                services.Remove(descriptor);

            // Replace with in-memory database
            services.AddDbContext<ConversionDbContext>(options =>
                options.UseInMemoryDatabase("ConversionTestDb_" + Guid.NewGuid()));
        });
    }
}
