using Conversion.Core.Converters;
using NUnit.Framework;

namespace Conversion.API.Tests.ConverterTests;

[TestFixture]
public sealed class TemperatureConverterTests
{
    private readonly TemperatureConverter _converter = new();

    [Test]
    [TestCase(100.0,  "Celsius",    "Fahrenheit", 212.0)]
    [TestCase(212.0,  "Fahrenheit", "Celsius",    100.0)]
    [TestCase(0.0,    "Celsius",    "Kelvin",      273.15)]
    [TestCase(273.15, "Kelvin",     "Celsius",       0.0)]
    [TestCase(32.0,   "Fahrenheit", "Kelvin",      273.15)]
    [TestCase(273.15, "Kelvin",     "Fahrenheit",   32.0)]
    [TestCase(-40.0,  "Celsius",    "Fahrenheit",  -40.0)] // crossover point
    public async Task Convert_KnownValues_AreCorrect(
        double input, string from, string to, double expected)
    {
        var result = await _converter.ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.01));
    }

    [Test]
    public void Convert_UnsupportedUnit_ThrowsArgumentException()
    {
        Assert.ThrowsAsync<ArgumentException>(() =>
            _converter.ConvertAsync(100m, "Celsius", "Rankine"));
    }

    [Test]
    public void Category_Is_Temperature()
        => Assert.That(_converter.Category, Is.EqualTo("Temperature"));

    [Test]
    public void SupportedUnits_ContainsThreeUnits()
        => Assert.That(_converter.SupportedUnits, Has.Count.EqualTo(3));
}
