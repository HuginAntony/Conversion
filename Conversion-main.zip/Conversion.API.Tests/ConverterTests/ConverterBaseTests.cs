﻿using Conversion.Core.Converters;
using NUnit.Framework;

namespace Conversion.API.Tests.ConverterTests;

[TestFixture]
public sealed class ConverterBaseTests
{
    [Test]
    [TestCase("Kilometers", "Miles",    1.0,    0.621371)]
    [TestCase("Miles",      "Kilometers", 1.0,  1.609344)]
    [TestCase("Meters",     "Feet",     1.0,    3.28084)]
    [TestCase("Feet",       "Meters",   1.0,    0.3048)]
    [TestCase("Inches",     "Centimeters", 1.0, 2.54)]
    [TestCase("Yards",      "Meters",   1.0,    0.9144)]
    [TestCase("Nautical Miles", "Kilometers", 1.0, 1.852)]
    public async Task Length_Conversions_AreCorrect(string from, string to, double input, double expected)
    {
        var result = await new LengthConverter().ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.001));
    }

    [Test]
    [TestCase("Kilograms", "Pounds",       1.0,     2.20462)]
    [TestCase("Pounds",    "Kilograms",    1.0,     0.453592)]
    [TestCase("Grams",     "Ounces",     100.0,     3.527396)]
    [TestCase("Stone",     "Kilograms",   1.0,      6.35029)]
    [TestCase("Metric Tonnes", "Kilograms", 1.0, 1000.0)]
    public async Task Mass_Conversions_AreCorrect(string from, string to, double input, double expected)
    {
        var result = await new MassConverter().ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.001));
    }

    [Test]
    [TestCase("km/h",   "mph",   100.0, 62.137119)]
    [TestCase("mph",    "km/h",  60.0,  96.56064)]
    [TestCase("m/s",    "km/h",  10.0,  36.0)]
    [TestCase("Knots",  "km/h",  1.0,   1.852)]
    public async Task Speed_Conversions_AreCorrect(string from, string to, double input, double expected)
    {
        var result = await new SpeedConverter().ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.01));
    }

    [Test]
    [TestCase("Litres",    "US Gallons",  1.0,   0.264172)]
    [TestCase("US Gallons","Litres",      1.0,   3.785412)]
    [TestCase("Litres",    "Millilitres", 1.0, 1000.0)]
    public async Task Volume_Conversions_AreCorrect(string from, string to, double input, double expected)
    {
        var result = await new VolumeConverter().ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.001));
    }

    [Test]
    [TestCase("Hectares", "Acres",  1.0,   2.471054)]
    [TestCase("sq km",    "sq mi",  1.0,   0.386102)]
    [TestCase("sq m",     "sq ft",  1.0,  10.763910)]
    public async Task Area_Conversions_AreCorrect(string from, string to, double input, double expected)
    {
        var result = await new AreaConverter().ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.001));
    }

    [Test]
    [TestCase("GB", "MB",    1.0,  1024.0)]
    [TestCase("MB", "KB",    1.0,  1024.0)]
    [TestCase("TB", "GB",    1.0,  1024.0)]
    [TestCase("Bytes", "KB", 1024.0, 1.0)]
    public async Task DataStorage_Conversions_AreCorrect(string from, string to, double input, double expected)
    {
        var result = await new DataStorageConverter().ConvertAsync((decimal)input, from, to);
        Assert.That((double)result.OutputValue, Is.EqualTo(expected).Within(0.0001));
    }

    [Test]
    public void Length_UnsupportedUnit_ThrowsArgumentException()
    {
        Assert.ThrowsAsync<ArgumentException>(() =>
            new LengthConverter().ConvertAsync(1m, "Furlongs", "Meters"));
    }

    [Test]
    public async Task Convert_SameUnit_ReturnsSameValue()
    {
        var result = await new LengthConverter().ConvertAsync(42m, "Meters", "Meters");
        Assert.That(result.OutputValue, Is.EqualTo(42m));
    }
}