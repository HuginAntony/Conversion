using System.Net.Http.Json;

namespace Conversion.API.Tests;

public static class Extensions
{
    public static async Task<T?> DeserializeAsync<T>(this HttpResponseMessage response)
        => await response.Content.ReadFromJsonAsync<T>();
}
