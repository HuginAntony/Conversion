using System.Net;
using System.Net.Http.Json;
using Conversion.Core.ApiModels;
using Conversion.Core.Models;
using NUnit.Framework;

namespace Conversion.API.Tests.ApiTests;

[TestFixture]
public sealed class ConvertControllerTests
{
    private HttpClient _client = null!;
    private TestFactory _factory = null!;

    [SetUp]
    public void Setup()
    {
        _factory = new TestFactory();
        _client  = _factory.CreateClient();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task GetCategories_Returns_AllSevenCategories()
    {
        var response = await _client.GetAsync("api/convert/categories");
        var result   = await response.DeserializeAsync<List<CategoryDto>>();

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        Assert.That(result, Has.Count.EqualTo(7));
    }

    [Test]
    [TestCase("Temperature", "Celsius", "Fahrenheit", 100, 212.0)]
    [TestCase("Temperature", "Celsius", "Kelvin",     0,   273.15)]
    [TestCase("Length",      "Kilometers", "Miles",   1,   0.621371)]
    [TestCase("Length",      "Meters", "Feet",        1,   3.28084)]
    [TestCase("Mass",        "Kilograms", "Pounds",   1,   2.204624)]
    [TestCase("Mass",        "Grams",     "Ounces",   100, 3.527397)]
    [TestCase("Speed",       "km/h",      "mph",      100, 62.137119)]
    [TestCase("Volume",      "Litres",    "US Gallons", 1, 0.264172)]
    [TestCase("Area",        "Hectares",  "Acres",    1,   2.471054)]
    [TestCase("Data Storage","GB",        "MB",       1,   1024.0)]
    public async Task Convert_KnownConversions_ReturnCorrectResult(
        string category, string from, string to, double input, double expected)
    {
        var request  = new ConversionRequest { FromUnit = from, ToUnit = to, Value = (decimal)input };
        var response = await _client.PostAsJsonAsync($"api/convert/{category}", request);
        var result   = await response.DeserializeAsync<ConversionResult>();

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        Assert.That((double)result!.OutputValue, Is.EqualTo(expected).Within(0.001));
    }

    [Test]
    public async Task Convert_UnknownCategory_Returns404()
    {
        var request  = new ConversionRequest { FromUnit = "Meters", ToUnit = "Feet", Value = 1m };
        var response = await _client.PostAsJsonAsync("api/convert/Nonsense", request);

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
    }

    [Test]
    public async Task Convert_UnknownUnit_Returns500()
    {
        var request  = new ConversionRequest { FromUnit = "Furlongs", ToUnit = "Feet", Value = 1m };
        var response = await _client.PostAsJsonAsync("api/convert/Length", request);

        // ArgumentException is mapped to 500 by GlobalExceptionHandler
        Assert.That((int)response.StatusCode, Is.InRange(400, 599));
    }

    [Test]
    public async Task GetUnits_ValidCategory_ReturnsList()
    {
        var response = await _client.GetAsync("api/convert/Temperature/units");
        var result   = await response.DeserializeAsync<List<string>>();

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        Assert.That(result, Contains.Item("Celsius"));
        Assert.That(result, Contains.Item("Fahrenheit"));
        Assert.That(result, Contains.Item("Kelvin"));
    }

    private sealed record CategoryDto(string Category, List<string> SupportedUnits);
}
