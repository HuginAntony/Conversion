using System.Net;
using System.Net.Http.Json;
using Conversion.Core.ApiModels;
using NUnit.Framework;

namespace Conversion.API.Tests.ApiTests;

[TestFixture]
public sealed class AuthControllerTests
{
    private HttpClient _client = null!;
    private TestFactory _factory = null!;

    [SetUp]
    public void Setup()
    {
        _factory = new TestFactory();
        _client  = _factory.CreateClient();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Register_NewUser_Returns200()
    {
        var username = "Tester" + Guid.NewGuid().ToString("N")[..8];
        var request  = new RegisterRequest { Username = username, Email = $"{username}@test.com", Password = username + "Ab1!" };

        var response = await _client.PostAsJsonAsync("auth/register", request);

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
    }

    [Test]
    public async Task Register_DuplicateUser_Returns409()
    {
        var username = "DupTester" + Guid.NewGuid().ToString("N")[..8];
        var request  = new RegisterRequest { Username = username, Email = $"{username}@test.com", Password = username + "Ab1!" };

        await _client.PostAsJsonAsync("auth/register", request);
        var response = await _client.PostAsJsonAsync("auth/register", request);

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
    }

    [Test]
    public async Task Login_ValidCredentials_ReturnsToken()
    {
        var username = "LoginTest" + Guid.NewGuid().ToString("N")[..8];
        var password = username + "Ab1!";
        var register = new RegisterRequest { Username = username, Email = $"{username}@test.com", Password = password };

        await _client.PostAsJsonAsync("auth/register", register);

        var loginRequest = new LoginRequest { Username = username, Password = password };
        var response     = await _client.PostAsJsonAsync("auth/login", loginRequest);
        var result       = await response.DeserializeAsync<LoginTokenResponse>();

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        Assert.That(result?.Token, Is.Not.Null.And.Not.Empty);
    }

    [Test]
    public async Task Login_InvalidCredentials_Returns400()
    {
        var response = await _client.PostAsJsonAsync("auth/login",
            new LoginRequest { Username = "doesnotexist", Password = "wrongpassword123!" });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    private sealed record LoginTokenResponse(string Token);
}
