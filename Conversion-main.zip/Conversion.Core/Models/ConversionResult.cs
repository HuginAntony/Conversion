namespace Conversion.Core.Models;

/// <summary>
/// Represents the result of a unit conversion operation.
/// </summary>
public sealed record ConversionResult(
    string Category,
    string FromUnit,
    string ToUnit,
    decimal InputValue,
    decimal OutputValue);
