﻿namespace Conversion.Core.ApiModels;

public class HistoryRequest
{
    public string ConversionCategory { get; set; } = string.Empty;
    public string ConversionFrom { get; set; } = string.Empty;
    public string ConversionTo { get; set; } = string.Empty;
    public decimal ValueToConvert { get; set; }
    public decimal ConvertedResult { get; set; }
    public string UserId { get; set; } = string.Empty;
}
