using System.ComponentModel.DataAnnotations;

namespace Conversion.Core.ApiModels;

public class ConversionRequest
{
    [Required]
    public string FromUnit { get; set; } = string.Empty;

    [Required]
    public string ToUnit { get; set; } = string.Empty;

    public decimal Value { get; set; }
}
