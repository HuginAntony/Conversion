using Conversion.Core.Contracts;

namespace Conversion.Core.Converters;

/// <summary>
/// Data storage converter. SI base unit: Byte.
/// Supports: Bytes, Kilobytes (KB), Megabytes (MB), Gigabytes (GB), Terabytes (TB), Petabytes (PB).
/// Uses binary (IEC) prefixes: 1 KB = 1024 Bytes.
/// </summary>
public sealed class DataStorageConverter : UnitConverterBase, IDataStorageConverter
{
    // All factors: 1 unit = X bytes
    private static readonly Dictionary<string, decimal> Factors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Bytes"]     = 1m,
        ["KB"]        = 1_024m,
        ["MB"]        = 1_048_576m,
        ["GB"]        = 1_073_741_824m,
        ["TB"]        = 1_099_511_627_776m,
        ["PB"]        = 1_125_899_906_842_624m,
    };

    public DataStorageConverter() : base(Factors) { }

    public override string Category => "Data Storage";
}
