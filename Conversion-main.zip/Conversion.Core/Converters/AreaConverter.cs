using Conversion.Core.Contracts;

namespace Conversion.Core.Converters;

/// <summary>
/// Area converter. SI base unit: Square Meter (sq m).
/// Supports: sq m, sq ft, sq km, sq mi, Hectares, Acres.
/// </summary>
public sealed class AreaConverter : UnitConverterBase, IAreaConverter
{
    // All factors: 1 unit = X square meters
    private static readonly Dictionary<string, decimal> Factors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["sq m"]      = 1m,
        ["sq ft"]     = 0.09290304m,
        ["sq km"]     = 1_000_000m,
        ["sq mi"]     = 2_589_988.110336m,
        ["Hectares"]  = 10_000m,
        ["Acres"]     = 4_046.8564224m,
    };

    public AreaConverter() : base(Factors) { }

    public override string Category => "Area";
}
