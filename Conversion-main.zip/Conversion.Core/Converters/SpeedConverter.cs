using Conversion.Core.Contracts;

namespace Conversion.Core.Converters;

/// <summary>
/// Speed converter. SI base unit: Meters per second (m/s).
/// Supports: m/s, km/h, mph, Knots, ft/s.
/// </summary>
public sealed class SpeedConverter : UnitConverterBase, ISpeedConverter
{
    // All factors: 1 unit = X meters per second
    private static readonly Dictionary<string, decimal> Factors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["m/s"]   = 1m,
        ["km/h"]  = 0.27777778m,
        ["mph"]   = 0.44704m,
        ["Knots"] = 0.51444444m,
        ["ft/s"]  = 0.3048m,
    };

    public SpeedConverter() : base(Factors) { }

    public override string Category => "Speed";
}
