﻿using Conversion.Core.Contracts;

namespace Conversion.Core.Converters;

/// <summary>
/// Length converter. SI base unit: Meter.
/// Supports: Meters, Kilometers, Miles, Feet, Centimeters, Inches, Yards, Nautical Miles.
/// </summary>
public sealed class LengthConverter : UnitConverterBase, ILengthConverter
{
    // All factors: 1 unit = X meters
    private static readonly Dictionary<string, decimal> Factors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Meters"]        = 1m,
        ["Kilometers"]    = 1_000m,
        ["Miles"]         = 1_609.344m,
        ["Feet"]          = 0.3048m,
        ["Centimeters"]   = 0.01m,
        ["Inches"]        = 0.0254m,
        ["Yards"]         = 0.9144m,
        ["Nautical Miles"] = 1_852m,
    };

    public LengthConverter() : base(Factors) { }

    public override string Category => "Length";
}
