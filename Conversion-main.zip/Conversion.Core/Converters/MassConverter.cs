﻿using Conversion.Core.Contracts;

namespace Conversion.Core.Converters;

/// <summary>
/// Mass converter. SI base unit: Kilogram.
/// Supports: Kilograms, Pounds, Grams, Ounces, Stone, Metric Tonnes, Short Tons.
/// </summary>
public sealed class MassConverter : UnitConverterBase, IMassConverter
{
    // All factors: 1 unit = X kilograms
    private static readonly Dictionary<string, decimal> Factors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Kilograms"]      = 1m,
        ["Pounds"]         = 0.45359237m,
        ["Grams"]          = 0.001m,
        ["Ounces"]         = 0.02834952m,
        ["Stone"]          = 6.35029318m,
        ["Metric Tonnes"]  = 1_000m,
        ["Short Tons"]     = 907.18474m,
    };

    public MassConverter() : base(Factors) { }

    public override string Category => "Mass";
}

