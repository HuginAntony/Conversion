using Conversion.Core.Contracts;
using Conversion.Core.Models;

namespace Conversion.Core.Converters;

/// <summary>
/// Base class for ratio-based unit converters.
/// Each derived type registers its units with their SI base conversion factors,
/// then conversion is handled generically: value → SI base → target unit.
/// </summary>
public abstract class UnitConverterBase : IUnitConverter
{
    // Factors represent: 1 unit = X SI-base units
    private readonly IReadOnlyDictionary<string, decimal> _toBase;

    protected UnitConverterBase(IReadOnlyDictionary<string, decimal> toBaseFactors)
    {
        _toBase = toBaseFactors;
        SupportedUnits = [.. toBaseFactors.Keys];
    }

    public abstract string Category { get; }

    public IReadOnlyList<string> SupportedUnits { get; }

    public Task<ConversionResult> ConvertAsync(
        decimal value,
        string fromUnit,
        string toUnit,
        CancellationToken cancellationToken = default)
    {
        ValidateUnit(fromUnit);
        ValidateUnit(toUnit);

        var inBase = value * _toBase[fromUnit];
        var result = Math.Round(inBase / _toBase[toUnit], 6);

        return Task.FromResult(new ConversionResult(Category, fromUnit, toUnit, value, result));
    }

    private void ValidateUnit(string unit)
    {
        if (!_toBase.ContainsKey(unit))
            throw new ArgumentException(
                $"Unit '{unit}' is not supported by the {Category} converter. Supported units: {string.Join(", ", SupportedUnits)}",
                nameof(unit));
    }
}
