using Conversion.Core.Contracts;

namespace Conversion.Core.Converters;

/// <summary>
/// Volume converter. SI base unit: Litre.
/// Supports: Litres, Millilitres, US Gallons, UK Gallons, US Fluid Ounces, Pints (UK), Cups (US).
/// </summary>
public sealed class VolumeConverter : UnitConverterBase, IVolumeConverter
{
    // All factors: 1 unit = X litres
    private static readonly Dictionary<string, decimal> Factors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Litres"]           = 1m,
        ["Millilitres"]      = 0.001m,
        ["US Gallons"]       = 3.78541178m,
        ["UK Gallons"]       = 4.54609188m,
        ["US Fluid Ounces"]  = 0.02957353m,
        ["Pints (UK)"]       = 0.56826125m,
        ["Cups (US)"]        = 0.23658824m,
    };

    public VolumeConverter() : base(Factors) { }

    public override string Category => "Volume";
}
