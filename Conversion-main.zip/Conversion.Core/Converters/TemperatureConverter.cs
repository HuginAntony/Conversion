﻿using Conversion.Core.Contracts;
using Conversion.Core.Models;

namespace Conversion.Core.Converters;

/// <summary>
/// Temperature converter. Supports: Celsius, Fahrenheit, Kelvin.
/// Temperature units use additive offsets and cannot use the ratio-based base class.
/// </summary>
public sealed class TemperatureConverter : ITemperatureConverter
{
    private static readonly IReadOnlyList<string> Units =
        ["Celsius", "Fahrenheit", "Kelvin"];

    public string Category => "Temperature";
    public IReadOnlyList<string> SupportedUnits => Units;

    public Task<ConversionResult> ConvertAsync(
        decimal value,
        string fromUnit,
        string toUnit,
        CancellationToken cancellationToken = default)
    {
        ValidateUnit(fromUnit);
        ValidateUnit(toUnit);

        var celsius = ToCelsius(value, fromUnit);
        var result = Math.Round(FromCelsius(celsius, toUnit), 6);

        return Task.FromResult(new ConversionResult(Category, fromUnit, toUnit, value, result));
    }

    private static decimal ToCelsius(decimal value, string unit) => unit.ToLower() switch
    {
        "celsius"    => value,
        "fahrenheit" => (value - 32m) * 5m / 9m,
        "kelvin"     => value - 273.15m,
        _            => throw new ArgumentException($"Unknown unit: {unit}")
    };

    private static decimal FromCelsius(decimal celsius, string unit) => unit.ToLower() switch
    {
        "celsius"    => celsius,
        "fahrenheit" => (celsius * 9m / 5m) + 32m,
        "kelvin"     => celsius + 273.15m,
        _            => throw new ArgumentException($"Unknown unit: {unit}")
    };

    private void ValidateUnit(string unit)
    {
        if (!Units.Contains(unit, StringComparer.OrdinalIgnoreCase))
            throw new ArgumentException(
                $"Unit '{unit}' is not supported by the Temperature converter. Supported units: {string.Join(", ", Units)}",
                nameof(unit));
    }
}
