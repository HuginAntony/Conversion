namespace Conversion.Core.Contracts;

/// <summary>Converts between speed units: km/h, mph, m/s, Knots, ft/s.</summary>
public interface ISpeedConverter : IUnitConverter { }
