namespace Conversion.Core.Contracts;

/// <summary>Converts between digital storage units: Bytes, KB, MB, GB, TB, PB.</summary>
public interface IDataStorageConverter : IUnitConverter { }
