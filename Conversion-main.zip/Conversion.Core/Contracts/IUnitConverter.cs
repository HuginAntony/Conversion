using Conversion.Core.Models;

namespace Conversion.Core.Contracts;

/// <summary>
/// Unified contract for any unit converter. Each implementation is self-describing
/// and can be discovered as a microservice without coupling to a specific unit pair.
/// </summary>
public interface IUnitConverter
{
    /// <summary>The conversion category (e.g. "Temperature", "Length").</summary>
    string Category { get; }

    /// <summary>All unit names supported by this converter.</summary>
    IReadOnlyList<string> SupportedUnits { get; }

    /// <summary>
    /// Convert <paramref name="value"/> from <paramref name="fromUnit"/> to <paramref name="toUnit"/>.
    /// </summary>
    /// <exception cref="ArgumentException">Thrown when a unit is not supported.</exception>
    Task<ConversionResult> ConvertAsync(
        decimal value,
        string fromUnit,
        string toUnit,
        CancellationToken cancellationToken = default);
}
