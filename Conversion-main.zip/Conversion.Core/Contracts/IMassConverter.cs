﻿using Conversion.Core.Models;

namespace Conversion.Core.Contracts;

/// <summary>
/// Converts between mass/weight units: Kilograms, Pounds, Grams, Ounces, Stone, Metric Tonnes, Short Tons.
/// </summary>
public interface IMassConverter : IUnitConverter { }
