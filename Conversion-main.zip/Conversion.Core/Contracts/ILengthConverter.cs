﻿using Conversion.Core.Models;

namespace Conversion.Core.Contracts;

/// <summary>
/// Converts between length units: Kilometers, Miles, Meters, Feet, Centimeters, Inches, Yards, Nautical Miles.
/// </summary>
public interface ILengthConverter : IUnitConverter { }
