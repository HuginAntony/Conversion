namespace Conversion.Core.Contracts;

/// <summary>Converts between area units: m², ft², km², mi², Hectares, Acres.</summary>
public interface IAreaConverter : IUnitConverter { }
