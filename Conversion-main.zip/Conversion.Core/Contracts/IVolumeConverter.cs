namespace Conversion.Core.Contracts;

/// <summary>Converts between volume units: Litres, US Gallons, UK Gallons, Millilitres, US Fluid Ounces, Pints, Cups.</summary>
public interface IVolumeConverter : IUnitConverter { }
