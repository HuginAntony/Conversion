﻿using Conversion.Core.Models;

namespace Conversion.Core.Contracts;

/// <summary>
/// Converts between temperature units: Celsius, Fahrenheit, Kelvin.
/// </summary>
public interface ITemperatureConverter : IUnitConverter { }
