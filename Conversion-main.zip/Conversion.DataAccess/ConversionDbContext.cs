﻿using Conversion.DataAccess.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Conversion.DataAccess;

public class ConversionDbContext : IdentityDbContext<ApplicationUser>
{
    public ConversionDbContext() { }

    public ConversionDbContext(DbContextOptions<ConversionDbContext> options) : base(options) { }

    public virtual DbSet<ConversionHistory> ConversionHistory => Set<ConversionHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ConversionDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }
}
