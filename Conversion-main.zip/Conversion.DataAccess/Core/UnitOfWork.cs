using Conversion.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Conversion.DataAccess.Core;

public sealed class UnitOfWork<TContext> : IUnitOfWork<TContext>
    where TContext : DbContext, new()
{
    private bool _disposed;

    public UnitOfWork(TContext dbContext)
    {
        Context = dbContext ?? new TContext();
    }

    public TContext Context { get; private set; }

    public void Commit() => Context.SaveChanges();

    public async Task CommitAsync(CancellationToken cancellationToken = default)
        => await Context.SaveChangesAsync(cancellationToken);

    public void Dispose(bool disposing)
    {
        if (_disposed || !disposing || Context == null) return;
        Context.Dispose();
        _disposed = true;
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}
