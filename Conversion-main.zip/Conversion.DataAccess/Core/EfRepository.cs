using System.Linq.Expressions;
using Conversion.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Conversion.DataAccess.Core;

public class EfRepository<TContext, TEntity> : IRepository<TEntity>
    where TContext : DbContext, new()
    where TEntity : class
{
    protected readonly IUnitOfWork<TContext> UnitOfWork;

    public EfRepository(IUnitOfWork<TContext> unitOfWork)
    {
        UnitOfWork = unitOfWork;
    }

    private DbSet<TEntity> Entities => UnitOfWork.Context.Set<TEntity>();

    public virtual IQueryable<TEntity> LazyGetAll()
        => Entities.AsQueryable();

    public virtual IQueryable<TEntity> LazyGet(Expression<Func<TEntity, bool>> predicate)
        => Entities.Where(predicate);

    public virtual IEnumerable<TEntity> GetAll()
        => Entities.AsEnumerable();

    public virtual IEnumerable<TEntity> Get(Expression<Func<TEntity, bool>> predicate)
        => Entities.Where(predicate).AsEnumerable();

    public virtual async Task<TEntity?> GetByIdAsync(object id, CancellationToken cancellationToken = default)
        => await Entities.FindAsync([id], cancellationToken);

    public virtual void Insert(TEntity entity)
        => Entities.Add(entity);

    public virtual void InsertRange(IEnumerable<TEntity> entities)
        => Entities.AddRange(entities);

    public virtual void Update(TEntity entity)
        => UnitOfWork.Context.Entry(entity).State = EntityState.Modified;

    public virtual void Delete(TEntity entity)
        => Entities.Remove(entity);
}
