using System.Linq.Expressions;

namespace Conversion.DataAccess.Interfaces;

public interface IRepository<TEntity> where TEntity : class
{
    IQueryable<TEntity> LazyGetAll();
    IQueryable<TEntity> LazyGet(Expression<Func<TEntity, bool>> predicate);
    IEnumerable<TEntity> GetAll();
    IEnumerable<TEntity> Get(Expression<Func<TEntity, bool>> predicate);
    Task<TEntity?> GetByIdAsync(object id, CancellationToken cancellationToken = default);
    void Insert(TEntity entity);
    void InsertRange(IEnumerable<TEntity> entities);
    void Update(TEntity entity);
    void Delete(TEntity entity);
}
