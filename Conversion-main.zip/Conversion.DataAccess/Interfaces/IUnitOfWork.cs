﻿namespace Conversion.DataAccess.Interfaces;

public interface IUnitOfWork<out TContext> : IDisposable
{
    TContext Context { get; }
    void Commit();
    Task CommitAsync(CancellationToken cancellationToken = default);
    void Dispose(bool disposing);
}