﻿using Conversion.DataAccess.Models;

namespace Conversion.DataAccess;

public class ConversionHistory
{
    public long HistoryId { get; set; }
    public string ConversionCategory { get; set; } = string.Empty;
    public string ConversionFrom { get; set; } = string.Empty;
    public string ConversionTo { get; set; } = string.Empty;
    public decimal ValueToConvert { get; set; }
    public decimal ConvertedResult { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public string UserId { get; set; } = string.Empty;

    public virtual ApplicationUser? User { get; set; }
}
